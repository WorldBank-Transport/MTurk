import csv

print("Hello World!")

def year_spam(start, end):
	spam = ''
	spam += '<option value="Before ' + str(start) + '">Before ' + str(start) + '</option>'
	for i in range(start, end+1):
		spam += '<option value="' + str(i) + '">' + str(i) + '</option>'
	return spam

country_list = []
with open("World Bank countries.csv", newline='') as csvfile:
	for row in csv.reader(csvfile):
		country_list.append(row[0])
print(country_list)

industry_list = []
with open("Industry.csv", newline='') as csvfile:
	for row in csv.reader(csvfile):
		industry_list.append(row[0])
print(industry_list)


def nationality_spam():
	spam = ''
	for i in country_list:
		spam += '<option value="' + i + '">' + i + '</option>'
	return spam


def industry_spam():
	spam = ''
	for i in industry_list:
		spam += '<option value="' + i + '">' + i + '</option>'
	return spam