import csv

def consensus_answer(answer_dict):
	count = 0
	correct_answer = 0
	correct_workers = []
	for answer in answer_dict:
		if len(answer_dict[answer]) > count:
			count = len(answer_dict[answer])
			correct_answer = answer
			correct_workers = answer_dict[correct_answer]
	return (correct_workers, correct_answer)

def read_file(file_name, answer_column):
	with open(file_name, newline='') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {'ans':0, 'id':0, 'approve':0, 'reject':0}
		answers = {}
		row_list = []
		for row in submissions_list:
			row_list.append(row)
			if row[0] == "HITId":
				position['ans'] = row.index(answer_column)
				position['id'] = row.index('WorkerId')
				position['approve'] = row.index('Approve')
				position['reject'] = row.index('Reject')
			else:
				a = row[position['ans']]
				if a in answers:
					answers[a].append(row[position['id']])
				else:
					answers[a] = [row[position['id']]]
	return (answers, row_list, position)

def write_file(file_name, row_list, position, good_ids):
	with open('New ' + file_name, 'w', newline='') as csvfile:
		approval_list = csv.writer(csvfile)
		for row in row_list:
			if row[0] == "HITId":
				approval_list.writerow(row)
			else:
				new_row = row.copy()
				if new_row[position['id']] in good_ids:
					new_row[position['approve']] = 'x'
				else:
					new_row[position['reject']] = 'Incorrect Answer(s)'
				approval_list.writerow(new_row)

def auto_approve(file_name, answer_column):
	(answers, row_list, position) = read_file(file_name, answer_column)
	(approved_ids, final_answer) = consensus_answer(answers)
	write_file(file_name, row_list, position, approved_ids)
	return final_answer

def multi_auto_approve(file_name, answer_columns):
	answer_list = {}
	good_ids = 0
	for answer_column in answer_columns:
		(answers, row_list, position) = read_file(file_name, start_column, answer_column)
		(approved_ids, final_answer) = consensus_answer(answers)
		answer_list[answer_column] = final_answer
		if good_ids == 0:
			good_ids = approved_ids
		else:
			for worker_id in good_ids:
				if worker_id not in approved_ids:
					good_ids.remove(worker_id)
	write_file(file_name, start_column, row_list, position, good_ids)	
	return answer_list

auto_approve("Example Data Cleaning Task.csv", "Answer.R Yea")