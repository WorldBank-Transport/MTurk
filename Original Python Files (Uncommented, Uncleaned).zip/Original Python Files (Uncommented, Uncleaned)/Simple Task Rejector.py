import csv

def simplify(word):
	return word.lower().replace(" ", "").replace(",","").replace(".","").replace("/","")

def read_file(file_name, bad_answers):
	with open(file_name, newline='', encoding = 'utf8') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {'id':0, 'check':0}
		row_list = []
		bad_workers = []
		for row in submissions_list:
			row_list.append(row)
			if row[0] == 'HITId':
				position['id'] = row.index('AssignmentId')
				position['check'] = row.index('Answer.University Name')
			else:
				if simplify(row[position['check']]) in bad_answers:
					bad_workers.append(row[position['id']])
	return (bad_workers, row_list, position)

def write_file(file_name, bad_workers, row_list, position):
	with open('Rejected ' + file_name, 'w', newline='', encoding = 'utf8') as csvfile:
		reject_list = csv.writer(csvfile)
		for row in row_list:
			if row[0] == "HITId":
				reject_list.writerow(row)
			else:
				new_row = row.copy()
				if new_row[position['id']] in bad_workers:
					new_row.append('')
					new_row.append('Incorrect University Name.')
				reject_list.writerow(new_row)

def auto_reject(file_name, bad_answers):
	(bad_workers, row_list, position) = read_file(file_name, bad_answers)
	write_file(file_name, bad_workers, row_list, position)

auto_reject("Task answers.csv",["na"])
