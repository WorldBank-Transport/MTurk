import csv

def read_file(file_name):
	with open(file_name, newline='') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {'id':0, 'total_hits':0, 'approved_hits':0, 'classifier':0}
		row_list = []
		respondents = []
		for row in submissions_list:
			row_list.append(row)
			if row[0] == 'Worker ID':
				position['total_hits'] = row.index('Number of HITs approved or rejected - Lifetime')
				position['approved_hits'] = row.index('Number of HITs approved - Lifetime')
				position['classifier'] = row.index('UPDATE-Completed survey once')
			else:
				if row[position['total_hits']] == "0" and row[position['approved_hits']] == "0":
					respondents.append(row[position['id']])
	return (respondents, row_list, position)

def write_file(file_name, respondents, row_list, position):
	with open('New ' + file_name, 'w', newline='') as csvfile:
		classification_list = csv.writer(csvfile)
		for row in row_list:
			if row[0] == 'Worker ID':
				classification_list.writerow(row)
			else:
				new_row = row.copy()
				if new_row[position['id']] in respondents:
					new_row[position['classifier']] = 100
				classification_list.writerow(new_row)

def auto_classify(file_name):
	(respondents, row_list, position) = read_file(file_name)
	print(respondents)
	write_file(file_name, respondents, row_list, position)
