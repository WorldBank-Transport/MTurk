import csv

def read_data(file_name, country_list):
	with open(file_name, newline='') as csvfile:
		data_list = csv.reader(csvfile)
		num = 0
		total = 0
		for row in data_list:
			if row[0] in country_list:
				num += float(row[1])*float(row[2])/100
				total += float(row[2])
	return str(num/total)

def read_file(file_name, category):
	with open(file_name, newline='') as csvfile:
		source_list = csv.reader(csvfile)
		country_list = []
		for row in source_list:
			if row[0] == "FCV":
				pos = row.index(category)
			else:
				country_list.append(row[pos])
	return country_list

def write_file(data_file, source_file, categories):
	with open('Country ' + data_file, 'w', newline='') as csvfile:
		cd_list = csv.writer(csvfile)
		for cat in categories:
			row = [cat, read_data(data_file, read_file(source_file, cat))]
			cd_list.writerow(row)

write_file("Active social media users.csv", "Country classifications.csv", ["FCV", "Low Income", "Low-Middle Income", "Upper-Middle Income", "High Income", "World"])
