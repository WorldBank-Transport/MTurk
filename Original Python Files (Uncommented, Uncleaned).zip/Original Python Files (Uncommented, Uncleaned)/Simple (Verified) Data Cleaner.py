import csv
import string

# def consensus_answer(answer_dict):
# 	count = 0
# 	correct_answer = 0
# 	correct_workers = []
# 	for answer in answer_dict:
# 		if len(answer_dict[answer]) > count:
# 			count = len(answer_dict[answer])
# 			correct_answer = answer
# 			correct_workers = answer_dict[correct_answer]
# 	return (correct_workers, correct_answer)

def close_words(word):
	new_words = [word]
	for i in range(len(word)):
		new_words += word[0:i] + word[i+1:len(word)]
		for p in string.ascii_lowercase:
			new_words += word[0:i] + p + word[i+1:len(word)]
	return new_words

def consensus_answer(response_dict, total):
	if len(response_dict) == 0:
		return ["", ""]
	else:
		count = 0
		good_responses = ""

		for response in response_dict:
			if response_dict[response] > count:
				count = response_dict[response]

		if count > 1 and count > total/2:
			for response in response_dict:
				if response_dict[response] == count:
					return [response + "; ", str(count) + " out of " + str(total)]

		else:
			return ["",""]

def simplify(word):
	return word.lower().replace(" ", "").replace(",","").replace(".","").replace(";","").replace("/","")

def simple_consensus(paired_answers, bad_answers, good_part):
	row_list = []
	for key in paired_answers.keys():
		current_row = []
		current_row += list(key)
		for j in range(len(paired_answers[key][0][2])):
			response_dict = {}
			total = 0
			for i in range(len(paired_answers[key])):
				# if simplify(paired_answers[key][i][2][j]) not in bad_answers:
				if simplify(paired_answers[key][i][2][j]) not in bad_answers and (good_part in simplify(paired_answers[key][i][2][j]) or j >= 2):
					total += 1
					# a = paired_answers[key][i][2][j]
					# if a not in response_dict:
					# 	response_dict[a] = 1
					# else:
					# 	response_dict[a] += 1
					if j < 2:
						for a in paired_answers[key][i][2][j].lower().replace(";",",").replace(" ", "").split(","):
							if a.strip() not in response_dict:
								response_dict[a.strip()] = 1
							else:
								response_dict[a.strip()] += 1
					else:
						for a in paired_answers[key][i][2][j].lower().replace(";",",").replace("(",",").replace(")",",").split(","):
							if len(a) > 0:
								not_in_dict = True
								for new_key in response_dict:
									if not_in_dict and a.strip() in close_words(new_key):
										response_dict[new_key] += 1
										not_in_dict = False
								if not_in_dict:
									response_dict[a.strip()] = 1
							# if a.strip() not in response_dict:
							# 	response_dict[a.strip()] = 1
							# else:
							# 	response_dict[a.strip()] += 1
			current_row += consensus_answer(response_dict, total)
		row_list.append(current_row)
	return row_list

def pair_up(current_dict):
	temp_dict = {}
	for key in current_dict:
		if len(current_dict[key]) > 1:
			temp_dict[key] = current_dict[key]
	return temp_dict

def read_file(file_name, question_columns, answer_columns):
	with open(file_name, newline='', encoding = 'utf8') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {}
		question_position = {}
		answer_position = {}
		answers = {}
		row_list = []
		for row in submissions_list:
			row_list.append(row)
			if row[0] == "HITId":
				position['a_id'] = row.index('AssignmentId')
				position['w_id'] = row.index('WorkerId')
				position['status'] = row.index('AssignmentStatus')
				for i in range(len(question_columns)):
					question_position[i] = row.index(question_columns[i])
				for i in range(len(answer_columns)):
					answer_position[i] = row.index(answer_columns[i])
			else:
				if row[position['status']] == "Approved":
					bad_key = []
					for i in range(len(question_position)):
						bad_key.append(row[question_position[i]])
					temp_key = tuple(bad_key)
					temp_val = [row[position['a_id']],row[position['w_id']],[]]
					for i in range(len(answer_position)):
						temp_val[2].append(row[answer_position[i]])
					if temp_key not in answers:
						answers[temp_key] = [temp_val]
					else:
						answers[temp_key] += [temp_val]
	return (answers, row_list, position, question_position, answer_position)

def write_file(file_name, row_list, question_columns, answer_columns):
	with open('Verified ' + file_name, 'w', newline='', encoding = 'utf8') as csvfile:
		rows = csv.writer(csvfile)
		top_row = []
		top_row += question_columns
		for c in answer_columns:
			top_row.append(c)
			top_row.append(" ")
		rows.writerow(top_row)
		for row in row_list:
			rows.writerow(row)

def auto_pairer(file_name, question_columns, answer_columns, bad_answers, good_part):
	(answers, row_list, position, question_position, answer_position) = read_file(file_name, question_columns, answer_columns)
	# paired_answers = pair_up(answers)
	row_list = simple_consensus(answers, bad_answers, good_part)
	write_file(file_name, row_list, question_columns, answer_columns)


# def auto_approve(file_name, answer_column):
# 	(answers, row_list, position) = read_file(file_name, answer_column)
# 	(approved_ids, final_answer) = consensus_answer(answers)
# 	write_file(file_name, row_list, position, approved_ids)
# 	return final_answer

# def multi_auto_approve(file_name, answer_columns):
# 	answer_list = {}
# 	good_ids = 0
# 	for answer_column in answer_columns:
# 		(answers, row_list, position) = read_file(file_name, start_column, answer_column)
# 		(approved_ids, final_answer) = consensus_answer(answers)
# 		answer_list[answer_column] = final_answer
# 		if good_ids == 0:
# 			good_ids = approved_ids
# 		else:
# 			for worker_id in good_ids:
# 				if worker_id not in approved_ids:
# 					good_ids.remove(worker_id)
# 	write_file(file_name, start_column, row_list, position, good_ids)	
# 	return answer_list

auto_pairer("task answers.csv", ["Input.Country", "Input.Rank"], ["Answer.1st Email Address", "Answer.2nd Email Address", "Answer.University Name"], ["na", "none"], "@")
