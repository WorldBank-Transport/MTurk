import csv

translate = {1: "1st", 2: "2nd", 3: "3rd", 4: "4th", 5: "5th", 6: "6th", 7: "7th", 8: "8th", 9: "9th", 10: "10th", 11: "11th", 12: "12th", 13: "13th", 14: "14th", 15: "15th"}

def read_file(file_name, columns, num):
	data = []
	pos = {}
	with open(file_name, newline='', encoding = 'latin-1') as csvfile:
		row_list = csv.reader(csvfile)
		for row in row_list:
			if columns == row:
				for c in columns:
					pos[c] = row.index(c)
			else:
				temp_data = [[]]
				for c in columns:
					if c != num:
						temp_data[0].append(row[pos[c]])
					else:
						temp_data.append(int(row[pos[c]]))
				data.append(temp_data)
	return data

def write_file(file_name, columns, data):
	with open("New " + file_name, 'w', newline='', encoding = 'utf8') as csvfile:
		extended_list = csv.writer(csvfile)
		extended_list.writerow(columns)
		for d in data:
			for i in range(d[1]):
				temp_row = []
				temp_row += d[0]
				temp_row.append(translate[i+1])
				extended_list.writerow(temp_row)

def auto_extend(file_name, columns, num):
	data = read_file(file_name, columns, num)
	write_file(file_name, columns, data)

auto_extend("EAP+.csv", ["Country", "Code", "Rank"], "Rank")