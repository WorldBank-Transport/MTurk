import csv

def read_key(key_name):
	with open(key_name, newline='', encoding = 'utf8') as csvfile:
		submissions_list = csv.reader(csvfile)
		pos = 0
		respondents = []
		for row in submissions_list:
			if row[0] == 'HITId':
				pos = row.index('WorkerId')
			else:
				respondents.append(row[pos])
	return respondents

def read_file(file_name):
	with open(file_name, newline='', encoding = 'utf8') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {'id':0, 'classifier':0}
		row_list = []
		for row in submissions_list:
			row_list.append(row)
			if row[0] == 'Worker ID':
				position['classifier'] = row.index('UPDATE-Answered Survey 2')
	return (row_list, position)

def write_file(file_name, respondents, row_list, position):
	with open('New ' + file_name, 'w', newline='', encoding = 'utf8') as csvfile:
		classification_list = csv.writer(csvfile)
		for row in row_list:
			if row[0] == 'Worker ID':
				classification_list.writerow(row)
			else:
				new_row = row.copy()
				if new_row[position['id']] in respondents:
					new_row[position['classifier']] = 100
				classification_list.writerow(new_row)

def auto_classify(key_name, file_name):
	respondents = read_key(key_name)
	print(len(respondents))
	(row_list, position) = read_file(file_name)
	write_file(file_name, respondents, row_list, position)

auto_classify("task workers.csv", "all workers.csv")