import csv
import string

def close_words(word):
	new_words = [word]
	for i in range(len(word)):
		new_words += word[0:i] + word[i+1:len(word)]
		for p in string.ascii_lowercase:
			new_words += word[0:i] + p + word[i+1:len(word)]
	return new_words

def simplify(word):
	return word.lower().replace(" ", "").replace(",","").replace(".","").replace(";","")

def contains(str1, str2):
	if (str1 in str2 and len(str1) > 4) or (str2 in str1 and len(str2) > 4):
		return True
	return False

def deep_contains(str1,str2):
	for temp_str2 in close_words(str2):
		if str1 in temp_str2 and len(str1) > 4:
			return True
	for temp_str1 in close_words(str1):
		if str2 in temp_str1 and len(str2) > 4:
			return True
	return False

def read_key(key_name, keys, answer):
	with open(key_name, newline='', encoding = 'latin-1') as csvfile:
		correct_list = csv.reader(csvfile)
		position = {}
		answers = {}
		for row in correct_list:
			if answer in row:
				for key in keys:
					position[key] = row.index(key)
				position[answer] = row.index(answer)
			else:
				if len(row[position[answer]]) > 0:
					temp_key = []
					for key in keys:
						temp_key.append(row[position[key]])
					if ";" not in row[position[answer]]:
						answers[tuple(temp_key)] = [row[position[answer]]]
					else:
						answers[tuple(temp_key)] = row[position[answer]].split(";")
	return answers

def read_file(file_name, keys, answer, answers):
	with open(file_name, newline='', encoding = 'latin-1') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {}
		pos = 0
		row_list = []
		correct_answers = []
		for row in submissions_list:
			row_list.append(row)
			if answer in row:
				pos = row.index("AssignmentId")
				for key in keys:
					position[key] = row.index(key)
				position[answer] = row.index(answer)
			else:
				temp_key = []
				for key in keys:
					temp_key.append(row[position[key]])
				if tuple(temp_key) in answers:
					for given_answer in answers[tuple(temp_key)]:
						if simplify(given_answer) != "na":
							if simplify(given_answer) in close_words(simplify(row[position[answer]])):
								correct_answers.append(row[pos])
							elif contains(simplify(given_answer), simplify(row[position[answer]])):
								correct_answers.append(row[pos])
							elif deep_contains(simplify(given_answer), simplify(row[position[answer]])):
								correct_answers.append(row[pos])
	return (correct_answers, row_list, pos)

def write_file(file_name, correct_answers, row_list, pos):
	with open('New ' + file_name, 'w', newline='', encoding = 'latin-1') as csvfile:
		approval_list = csv.writer(csvfile)
		for row in row_list:
			if row[0] == "HITId":
				approval_list.writerow(row)
			else:
				new_row = row.copy()
				if new_row[pos] in correct_answers:
					new_row.append ('x')
				approval_list.writerow(new_row)

def auto_classify(key_name, file_name, keys, answer):
	answers = read_key(key_name, keys, answer)
	(correct_answers, row_list, pos) = read_file(file_name, keys, answer, answers)
	write_file(file_name, correct_answers, row_list, pos)

auto_classify("Correct Universities (SSA).csv", "task answers.csv", ["Input.Country", "Input.Rank"], "Answer.University Name")
