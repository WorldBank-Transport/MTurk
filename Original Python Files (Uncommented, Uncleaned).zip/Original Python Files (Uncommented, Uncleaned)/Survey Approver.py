import csv

def close_words(words):
	new_words = []
	for word in words:
		new_words.append(word)
		for i in range(len(word)):
			new_words.append(word[0:i] + word[i+1:len(word)])
	return new_words

def simplify(word):
	return word.lower().replace(" ", "").replace(",","").replace(".","")

def read_file(file_name, answers, loose_answers):
	with open(file_name, newline='', encoding = 'utf8') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {'id':0, 'check':0}
		row_list = []
		correct_answers = []
		for row in submissions_list:
			row_list.append(row)
			if row[0] == 'HITId':
				position['id'] = row.index('WorkerId')
				position['check'] = row.index('Answer.Reading check')
			else:
				not_done = True
				if simplify(row[position['check']]) in close_words(answers):
					correct_answers.append(row[position['id']])
					not_done = False
				else:
					for entry in close_words([simplify(row[position['check']])]):
						for answer in answers:
							if answer in entry and not_done:
								correct_answers.append(row[position['id']])
								not_done = False
						for loose_answer in loose_answers:
							if loose_answer in entry and not_done:
								correct_answers.append(row[position['id']])
								not_done = False
	return (correct_answers, row_list, position)

def write_file(file_name, correct_answers, row_list, position):
	with open('New ' + file_name, 'w', newline='', encoding = 'utf8') as csvfile:
		approval_list = csv.writer(csvfile)
		for row in row_list:
			if row[0] == "HITId":
				approval_list.writerow(row)
			else:
				new_row = row.copy()
				if new_row[position['id']] in correct_answers:
					new_row.append ('x')
				# else:
				# 	new_row.append('')
				# 	new_row.append('Incorrect Answer to the first question')
				approval_list.writerow(new_row)

def auto_approve(file_name, answers, loose_answers):
	(correct_answers, row_list, position) = read_file(file_name, answers, loose_answers)
	write_file(file_name, correct_answers, row_list, position)

auto_approve("WDR survey responses.csv",["automationandinnovation","automationinnovation","innovationautomation","innovationandautomation"], ["innovation","automation"])
