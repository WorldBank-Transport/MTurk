import csv

def simplify(word):
	return word.lower().replace(" ", "").replace(",","").replace(".","").replace("/","")

def read_file(file_name, good_answers, good_ids):
	with open(file_name, newline='', encoding = 'utf8') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {'id':0, 'check':0}
		row_list = []
		good_workers = []
		for row in submissions_list:
			row_list.append(row)
			if row[0] == 'HITId':
				position['id'] = row.index('AssignmentId')
				position['worker'] = row.index('WorkerId')
				position['check'] = row.index('Answer.Reading check 1')
			else:
				if simplify(row[position['check']]) in good_answers or "12" in simplify(row[position['check']]) or "twelve" in simplify(row[position['check']]):
					good_workers.append(row[position['id']])
				elif row[position['worker']] in good_ids:
					good_workers.append(row[position['id']])
	return (good_workers, row_list, position)

def write_file(file_name, good_workers, row_list, position):
	with open('Approved ' + file_name, 'w', newline='', encoding = 'utf8') as csvfile:
		reject_list = csv.writer(csvfile)
		for row in row_list:
			if row[0] == "HITId":
				reject_list.writerow(row)
			else:
				new_row = row.copy()
				if new_row[position['id']] in good_workers:
					new_row.append('x')
				reject_list.writerow(new_row)

def auto_approve(file_name, good_answers, good_ids):
	(good_workers, row_list, position) = read_file(file_name, good_answers, good_ids)
	write_file(file_name, good_workers, row_list, position)

auto_approve("Task answers.csv",["12"],["AG6OGD9UEG6WY","A1HSJ78RU15836","A33LYDQNS8O13L","A2MOUY1UWKJGVG"])
