import csv

def url_extract(answer):
	ans = answer.split()
	urls = []
	for phrase in ans:
		if "http" in phrase:
			urls.append(phrase)
	return urls

def read_file(file_name):
	with open(file_name, newline='', encoding = 'utf8') as csvfile:
		submissions_list = csv.reader(csvfile)
		position = {'id':0, 'feedback':0}
		row_list = [[],[],[],[],[],[]]
		for row in submissions_list:
			if row[0] == 'HITId':
				position['id'] = row.index('WorkerId')
				position['feedback'] = row.index('Answer.Feedback')
			else:
				if "http" in row[position['feedback']]:
					row_list[0].append(row[position['id']])
					urls = url_extract(row[position['feedback']])
					for i in range(1, 6):
						if i <= len(urls):
							row_list[i].append(urls[i-1])
						else:
							row_list[i].append("")

	return row_list

def write_file(file_name, row_list):
	with open('URL answers.csv', 'w', newline='', encoding = 'utf8') as csvfile:
		url_list = csv.writer(csvfile)
		for row in row_list:
			url_list.writerow(row)

def auto_find(file_name):
	row_list = read_file(file_name)
	write_file(file_name, row_list)

auto_find("URL source.csv")
