import csv

def read_data(file_name, country_list, year):
	with open(file_name, newline='') as csvfile:
		data_list = csv.reader(csvfile)
		position = {'country':0, 'year':0}
		data = []
		for row in data_list:
			if row[0] == "Country Name":
				position['country'] = row.index("Country Name")
				position['year'] = row.index(str(year))
			else:
				if row[position['country']] in country_list:
					if row[position['year']] != "":
						data.append([row[position['country']], float(row[position['year']])])
		data.sort(key=lambda x: x[1])
	return data

def read_file(file_name, category):
	with open(file_name, newline='') as csvfile:
		source_list = csv.reader(csvfile)
		country_list = []
		for row in source_list:
			if row[0] == "FCV":
				pos = row.index(category)
			else:
				country_list.append(row[pos])
	return country_list

def write_file(data_file, source_file, start_year, end_year, categories):
	with open('Country ' + data_file, 'w', newline='') as csvfile:
		cd_list = csv.writer(csvfile)
		header_row = [""]
		for year in range(start_year, end_year + 1):
			header_row.append(str(year))
		cd_list.writerow(header_row)
		for cat in categories:
			row1 = [cat + " low"]
			row2 = [cat + " average"]
			row3 = [cat + " high"]
			for year in range(start_year, end_year + 1):
				country_list = read_file(source_file, cat)
				data = read_data(data_file, country_list, year)
				if len(data) == 0:
					floor = "No Data"
					mean = "No Data"
					ceiling = "No Data"
				else:
					floor = data[0][1]
					mean = sum(d for _,d in data)/len(data)
					ceiling = data[-1][1]
				row1.append(str(floor))
				row2.append(str(mean))
				row3.append(str(ceiling))
			cd_list.writerow(row1)
			cd_list.writerow(row2)
			cd_list.writerow(row3)

write_file("Fixed broadband subscriptions.csv", "Country classifications.csv", 1960, 2016, ["FCV", "Low Income", "Low-Middle Income", "Upper-Middle Income", "High Income"])
