import csv
from string import punctuation

def transform(word):
	# return ''.join(c for c in word if c not in punctuation).lower().split(" ")
	w = word.lower()
	for p in '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~':
		w = w.replace(p, " ")
	return w.split(" ")

def read_file(file_name, answer_columns, background_columns):
	with open(file_name, newline='', encoding = 'utf8') as csvfile:
		submissions_list = csv.reader(csvfile)
		answer_position = []
		background_position = []
		word_dict = {}
		status = 0
		for row in submissions_list:
			if row[0] == 'HITId':
				status = row.index("AssignmentStatus")
				for i in range(len(answer_columns)):
					answer_position.append(row.index(answer_columns[i]))
					word_dict[answer_columns[i]] = {}
				for i in range(len(background_columns)):
					background_position.append(row.index(background_columns[i]))
					word_dict[background_columns[i]] = {}
			else:
				if row[status] == "Approved":
					for i in range(len(answer_columns)):
						temp_word_list = transform(row[answer_position[i]])
						for word in temp_word_list:
							if word not in word_dict[answer_columns[i]]:
								word_dict[answer_columns[i]][word] = 1
							else:
								word_dict[answer_columns[i]][word] += 1
					for i in range(len(background_columns)):
						word = row[background_position[i]]
						if word not in word_dict[background_columns[i]]:
							word_dict[background_columns[i]][word] = 1
						else:
							word_dict[background_columns[i]][word] += 1
	return word_dict

def write_file(file_name, columns, word_stats):
	for column in columns:
		with open(column + " statistics.csv", 'w', newline='', encoding = 'utf8') as csvfile:
			rows = csv.writer(csvfile)
			rows.writerow([column])
			for row in word_stats[column]:
				rows.writerow(row)

def auto_approve(file_name, answer_columns, background_columns):
	word_dict = read_file(file_name, answer_columns, background_columns)
	columns = answer_columns + background_columns
	word_stats = {}
	for key in word_dict:
		temp_list = []
		for minorkey in word_dict[key]:
			if len(minorkey) > 3 or key in background_columns:
				temp_list.append([minorkey, word_dict[key][minorkey]])
		temp_list.sort(key=lambda x: x[1], reverse = True)
		word_stats[key] = temp_list
	write_file(file_name, columns, word_stats)

k = auto_approve("WDR survey responses.csv",["Answer.New", "Answer.Old decline", "Answer.Old steady"], ["Answer.Nationality"])
