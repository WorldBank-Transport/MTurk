import csv

def read_file(file_names):
	big_list = []
	for file in file_names:
		with open(file, newline='', encoding = 'utf8') as csvfile:
			small_list = []
			csv_list = csv.reader(csvfile)
			for row in csv_list:
				small_list.append(row[0])
			big_list.append(small_list)
	return big_list

def write_file(file_name, big_list):
	with open(file_name, 'w', newline='', encoding = 'utf8') as csvfile:
		combined_list = csv.writer(csvfile)
		list1 = big_list[0][1:]
		list2 = big_list[1][1:]
		combined_list.writerow([big_list[0][0],big_list[1][0]])
		for i1 in list1:
			for i2 in list2:
				combined_list.writerow([i1,i2])

def auto_combine(file_names, file_name):
	big_list = read_file(file_names)
	print(big_list)
	write_file(file_name, big_list)

auto_combine(["Country.csv", "Rank.csv"], "Email Collection.csv")
